package com.zebrunner.carina.demo.mobile.gui.pages.common;

import org.openqa.selenium.WebDriver;

import com.zebrunner.carina.webdriver.gui.AbstractPage;

public class ChartsPageBase extends AbstractPage {

    public ChartsPageBase(WebDriver driver) {
        super(driver);
    }

}
